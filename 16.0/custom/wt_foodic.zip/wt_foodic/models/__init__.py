# -*- coding: utf-8 -*-

from . import connector
from . import branches
from . import payment_methods
from . import categories
from . import products
from . import pos_orders
from . import res_partner
from . import purchase_order
from . import analytic_account_foodics_branch_name